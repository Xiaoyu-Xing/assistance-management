# CS4400Database course project on disaster assistance management system (DAMS)
# This is a place for group project of CS4400 and study notes.
