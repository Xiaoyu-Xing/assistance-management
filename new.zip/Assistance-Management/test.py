print(all(((,))))


